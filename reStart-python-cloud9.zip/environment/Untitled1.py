python --version
print("Hello World")
print(10+20)