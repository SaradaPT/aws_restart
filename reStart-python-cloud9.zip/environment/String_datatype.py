a = "Sarada "
b = "Prasanna "
c = "Tripathy"
print(a+b+c)
Name = input("What is your name? ")
Education = input("What is your Qualification  ")
Age = input("What is your Age ")
print("Hello {},Your Age is {},and Your have completed {}".format(Name,Age,Education))


color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(Name,color,animal))
