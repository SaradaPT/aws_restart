#List
a = [10,20,30,40,'Sarada',True]
print(a)
print(type(a))
print(a[4])
myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
myFruitList[2] = "orange"
print(myFruitList)
#Tuple
a = (10,20,30,40,'Sarada',False)
print(a)
print(type(a))
print(a[4])
#Dict
data = {'Name':'Sarada','Age':25,'Education':'MCA'}
print(data)
print(type(data))