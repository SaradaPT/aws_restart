#if
name = input("Enter name:")
if name == "Sarada":
    print("Hello Sarada,Good Evening")
    
#if-else
name = input("Enter name:")
if name == "Sarada":
    print("Hello Sarada,Good Evening")
else:
    print("Hello Guest,Good Evening")
print("How are you!!!")

#if-else-elif
a = int(input("Enter first number"))
b = int(input("Enter Second number"))
c = int(input("Enter Third number"))
if a>b and a>c:
    print("Biggest number:",a)
elif b>c:
    print("Biggest number:",b)
else:
    print("Biggest number:",c)
