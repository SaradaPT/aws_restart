Name = "Sarada"
print(type(Name))
print(Name)
a = 10
print(a)
b = True
print(b)
c = 1.50
print(c)
d = 10+0j
print(d)
print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(str(Name) + " is of the data type " + str(type(Name)))
print(str(a) + " is of the data type " + str(type(a)))
print(str(b) + " is of the data type " + str(type(b)))