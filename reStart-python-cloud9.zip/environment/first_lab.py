print("Hello Sarada Prasanna Tripathy")
print(10+20)
print("Today is our First Python Class")